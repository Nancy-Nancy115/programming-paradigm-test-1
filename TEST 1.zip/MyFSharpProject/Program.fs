﻿let salaries = [75000; 48000; 120000; 190000; 300113; 92000; 36000]




                    //a. High-income salaries are greater than $100,000
let highIncomeSalaries = salaries |> List.filter (fun x -> x > 100000)
printfn "High-income salaries: %A" highIncomeSalaries




                                //b. Calculate tax
let calculateTax salary =
    if salary <= 50000 then salary * 10 / 100
    elif salary <= 100000 then salary * 20 / 100
    else salary * 30 / 100

let taxes = salaries |> List.map calculateTax
printfn "Taxes for all salaries: %A" taxes




                                //c. Adjust low salaries
let adjustedSalaries = 
    salaries |> List.map (fun x -> if x < 49020 then x + 20000 else x)
printfn "Adjusted salaries: %A" adjustedSalaries




                                //d. Sum mid-range salaries
let midRangeSalaries = salaries |> List.filter (fun x -> x >= 50000 && x <= 100000)
let totalMidRange = midRangeSalaries |> List.reduce (+)
printfn "Sum of mid-range salaries: %d" totalMidRange





                
                                   //2. Tail Recursion
let rec sumMultiplesOf3 n acc =
    if n = 0 then acc
    else sumMultiplesOf3 (n - 3) (acc + n)

let result = sumMultiplesOf3 27 0
printfn "Sum of multiples of 3 up to 27: %d" result
